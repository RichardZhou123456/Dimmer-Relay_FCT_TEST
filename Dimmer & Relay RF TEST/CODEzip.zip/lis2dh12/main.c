/* Copyright (c) 2014 Nordic Semiconductor. All Rights Reserved.
 *
 * The information contained herein is property of Nordic Semiconductor ASA.
 * Terms and conditions of usage are described in detail in NORDIC
 * SEMICONDUCTOR STANDARD SOFTWARE LICENSE AGREEMENT.
 *
 * Licensees are granted free, non-transferable use of the information. NO
 * WARRANTY of ANY KIND is provided. This heading must NOT be removed from
 * the file.
 *
 */

/** @file
 *
 * @defgroup ble_sdk_app_template_main main.c
 * @{
 * @ingroup ble_sdk_app_template
 * @brief Template project main file.
 *
 * This file contains a template for creating a new application. It has the code necessary to wakeup
 * from button, advertise, get a connection restart advertising on disconnect and if no new
 * connection created go back to system-off mode.
 * It can easily be used as a starting point for creating a new application, the comments identified
 * with 'YOUR_JOB' indicates where and how you can customize.
 */

#include <stdint.h>
#include <string.h>
#include "nrf_gpio.h"
#include "SEGGER_RTT.h"
#include "app_timer.h"

#include "bd_lis3dh_driver.h"
#include "hal_acc.h"
#include "bd_spi_master.h"

#define LED0_PIN 18

#define APP_TIMER_PRESCALER              0                                          /**< Value of the RTC1 PRESCALER register. */
#define APP_TIMER_OP_QUEUE_SIZE          6                                          /**< Size of timer operation queues. */

#define LIS3DH_TIMEOUT_DELAY      APP_TIMER_TICKS(2000, 0)                     /* 2S */

#define DEAD_BEEF                         0xDEADBEEF                                        /**< Value used as error code on stack dump, can be used to identify stack location on stack unwind. */

APP_TIMER_DEF(m_lis3dh_timer_id);

extern AxesRaw_t accData[32]; // Read acc data from FIFO


/**@brief Handle events from button timer.
 *
 * @param[in]   p_context   parameter registered in timer start function.
 */
static void lis3dh_timer_handler(void * p_context)
{
    SEGGER_RTT_printf(0,"lis3dh_timer_handler!!!\n");
    int error_no = 0;

    uint8_t transfer_size;
    int32_t compose;
    int16_t accX,accY,accZ;
    uint8_t acc_ii = 0;
    
    hal_acc_GetFifoData(&transfer_size);
    SEGGER_RTT_printf(0, "sensor_timer_handle transfer_size: [%d]\n", transfer_size);
    for(; acc_ii < transfer_size; acc_ii++) 
    {
            accX = (accData[acc_ii].AXIS_X>>3);  // mg
            accY = (accData[acc_ii].AXIS_Y>>3);
            accZ = (accData[acc_ii].AXIS_Z>>3);
            SEGGER_RTT_printf(0, "sensor_timer_handle accX: [%d], accY: [%d], accZ: [%d]\n", accX, accY, accZ);

    }
}

/**@brief Function for the Timer initialization.
 *
 * @details Initializes the timer module. This creates and starts application timers.
 */
static void timers_init(void)
{
    uint32_t err_code = 0;
    NRF_CLOCK->EVENTS_LFCLKSTARTED = 0;
    NRF_CLOCK->TASKS_LFCLKSTART = 1;
    while(NRF_CLOCK->EVENTS_LFCLKSTARTED == 0)
    {
        //donoting
    }
    NRF_CLOCK->EVENTS_LFCLKSTARTED = 0;
    // Initialize timer module.
    APP_TIMER_INIT(APP_TIMER_PRESCALER, APP_TIMER_OP_QUEUE_SIZE, false);
    err_code = app_timer_create(&m_lis3dh_timer_id,
                            APP_TIMER_MODE_REPEATED,
                            lis3dh_timer_handler);
    APP_ERROR_CHECK(err_code);
    err_code = app_timer_start(m_lis3dh_timer_id, LIS3DH_TIMEOUT_DELAY, NULL);
    APP_ERROR_CHECK(err_code);
}

/**@brief Function for application main entry.
 */
int main(void)
{
    uint32_t err_code = 0;
    SEGGER_RTT_printf(0,"Start err_code: %d... ...\n", err_code);
    nrf_gpio_cfg_output(LED0_PIN);
    timers_init();
    hal_acc_init();
    hal_acc_enable();
    // Enter main loop.
    for (;;)
    {
        nrf_gpio_pin_toggle(LED0_PIN);
        nrf_delay_ms(500);
    }
}

/**
 * @}
 */
