extern void lis2dh12_init(void);
extern void read_g_sensor_data(void);