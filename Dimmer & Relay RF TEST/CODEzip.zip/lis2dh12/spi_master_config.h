/* Copyright (c) [2014 Baidu]. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * File Name          : 
 * Author             : 
 * Version            : $Revision:$
 * Date               : $Date:$
 * Description        : 
 *                      
 * HISTORY:
 * Date               | Modification                    | Author
 * 28/03/2014         | Initial Revision                | 
 
 */
#ifndef SPI_MASTER_CONFIG_H
#define SPI_MASTER_CONFIG_H

#define SPI_OPERATING_FREQUENCY  ( 0x02000000UL << (uint32_t)Freq_8Mbps)  /*!< Slave clock frequency. */
#define NUMBER_OF_TEST_BYTES     2    /*!< number of bytes to send to slave to test if Initialization was successful */
#define TEST_BYTE                0xBB /*!< Randomly chosen test byte to transmit to spi slave */
#define TIMEOUT_COUNTER          0x3000UL  /*!< timeout for getting rx bytes from slave */

/* GPIO pin number for SPI */
//#define SPI_PSELSCK0              NRF_GPIO_PIN_MAP(0,6)  /*!< GPIO pin number for SPI clock (note that setting this to 31 will only work for loopback purposes as it not connected to a pin) */
//#define SPI_PSELMOSI0             2 /*!< GPIO pin number for Master Out Slave In    */
//#define SPI_PSELMISO0             3   /*!< GPIO pin number for Master In Slave Out    */
//#define SPI_PSELSS0               5  /*!< GPIO pin number for Slave Select           */
#define SPI_PSELSCK0              NRF_GPIO_PIN_MAP(1,6)  /*!< GPIO pin number for SPI clock (note that setting this to 31 will only work for loopback purposes as it not connected to a pin) */
#define SPI_PSELMOSI0             NRF_GPIO_PIN_MAP(1,2) /*!< GPIO pin number for Master Out Slave In    */
#define SPI_PSELMISO0             NRF_GPIO_PIN_MAP(1,1) /*!< GPIO pin number for Master In Slave Out    */
#define SPI_PSELSS0               NRF_GPIO_PIN_MAP(1,5)   /*!< GPIO pin number for Slave Select           */

#endif /* SPI_MASTER_CONFIG_H */
