#include <stdint.h>
#include <string.h>
#include "nrf_gpio.h"
#include "SEGGER_RTT.h"
#include "app_timer.h"

#include "bd_lis3dh_driver.h"
#include "hal_acc.h"
#include "bd_spi_master.h"
#define DEAD_BEEF                         0xDEADBEEF                                        /**< Value used as error code on stack dump, can be used to identify stack location on stack unwind. */

extern AxesRaw_t accData[32]; // Read acc data from FIFO


void read_g_sensor_data(void)
{
    SEGGER_RTT_printf(0,"read g_sensor_data\n");
    int error_no = 0;

    uint8_t transfer_size;
    int32_t compose;
    int16_t accX,accY,accZ;
    uint8_t acc_ii = 0;
    
    hal_acc_GetFifoData(&transfer_size);
    SEGGER_RTT_printf(0, "sensor_timer_handle transfer_size: [%d]\n", transfer_size);
    for(; acc_ii < transfer_size; acc_ii++) 
    {
            accX = (accData[acc_ii].AXIS_X>>3);  // mg
            accY = (accData[acc_ii].AXIS_Y>>3);
            accZ = (accData[acc_ii].AXIS_Z>>3);
            SEGGER_RTT_printf(0, "sensor_timer_handle accX: [%d], accY: [%d], accZ: [%d]\n", accX, accY, accZ);

    }
}

void lis2dh12_init(void)
{
    uint32_t err_code = 0;
    SEGGER_RTT_printf(0,"Start err_code: %d... ...\n", err_code);
    //nrf_gpio_cfg_output(LED0_PIN);
    hal_acc_init();
    hal_acc_enable();
    read_g_sensor_data();
}