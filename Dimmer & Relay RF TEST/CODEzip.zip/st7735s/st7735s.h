#ifndef __ST7735S_H
#define __ST7735S_H

#define WHITE         	 0xFFFF
#define BLACK         	 0x0000	  
#define BLUE           	 0x001F  
#define BRED             0XF81F

void LCD_Clear(uint16_t color);


void LCD_Init(void);
void LCD_ShowString(uint16_t x,uint16_t y,const uint8_t *p,uint16_t color);
void LCD_ShowNum(uint16_t x,uint16_t y,uint16_t num,uint8_t len,uint16_t color);

#endif
