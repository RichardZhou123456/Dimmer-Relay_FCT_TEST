#include <nrfx_gpiote.h>
#include "st7735s.h"
#include "oledfont.h"
#include "nrf_delay.h"
#include "nrf_gpio.h"


#define LCD_RST   12
#define LCD_BL    13
#define LCD_CD    4
#define LCD_SCL   NRF_GPIO_PIN_MAP(1,9)
#define LCD_SDA   6
#define LCD_CS    8



 		   



void LCD_GPIO_Init(void)
{
  nrf_gpio_cfg_output(LCD_RST);
  nrf_gpio_cfg_output(LCD_BL);
  nrf_gpio_cfg_output(LCD_CD);
  nrf_gpio_cfg_output(LCD_SCL);
  nrf_gpio_cfg_output(LCD_SDA);
  nrf_gpio_cfg_output(LCD_CS);
}


void LCD_WriteCMD(uint8_t cmd)
{
  uint8_t i;
  nrf_gpio_pin_write(LCD_CS,0);
  nrf_gpio_pin_write(LCD_CD,0);
  for(i=0;i<8;i++)
  {
          nrf_gpio_pin_write(LCD_SCL,0);
          if(cmd&0x80)nrf_gpio_pin_write(LCD_SDA,1);
          else nrf_gpio_pin_write(LCD_SDA,0);
          nrf_gpio_pin_write(LCD_SCL,1);
          cmd<<=1;
  }
  nrf_gpio_pin_write(LCD_CS,1);
}

void LCD_WriteData(uint8_t dat)
{
  uint8_t i;
  nrf_gpio_pin_write(LCD_CS,0);
  nrf_gpio_pin_write(LCD_CD,1);
  for(i=0;i<8;i++)
  {
          nrf_gpio_pin_write(LCD_SCL,0);
          if(dat&0x80)nrf_gpio_pin_write(LCD_SDA,1);
          else nrf_gpio_pin_write(LCD_SDA,0);
          nrf_gpio_pin_write(LCD_SCL,1);
          dat<<=1;
  }
  nrf_gpio_pin_write(LCD_CS,1);
}


void LCD_Write_Color(uint16_t color)
{
  LCD_WriteData((uint8_t)(color>>8));
  LCD_WriteData((uint8_t)(color&0xFF));
}


void LCD_Setwindow(uint8_t xstart,uint8_t xend, uint8_t ystart, uint8_t yend)
{
  LCD_WriteCMD(0x2A); 
  LCD_WriteData((xstart+2)>>8);
  LCD_WriteData(xstart+2);
  LCD_WriteData((xend+2)>>8);  
  LCD_WriteData(xend+2);

  LCD_WriteCMD(0x2B); 
  LCD_WriteData((ystart+3)>>8);
  LCD_WriteData(ystart+3);
  LCD_WriteData((yend+3)>>8);  
  LCD_WriteData(yend+3);

  LCD_WriteCMD(0x2C); 
} 

void LCD_Clear(uint16_t color)
{
  uint32_t index=0;       
  LCD_Setwindow(0,127,0,127);
  for(index=0;index<16384;index++)
  {
      LCD_Write_Color(color);
  }
}

void LCD_Init(void)
{
  LCD_GPIO_Init();
  
  nrf_gpio_pin_write(LCD_SCL,1);
  nrf_gpio_pin_write(LCD_CS,1);
  nrf_gpio_pin_write(LCD_RST,0);
  nrf_delay_ms(50);
  nrf_gpio_pin_write(LCD_RST,1);
  nrf_delay_ms(100);
      
  LCD_WriteCMD(0x11);
  nrf_delay_ms(120); 

  LCD_WriteCMD(0xB1); 
  LCD_WriteData(0x05);
  LCD_WriteData(0x3A);
  LCD_WriteData(0x3A);
  LCD_WriteCMD(0xB2); 
  LCD_WriteData(0x05);
  LCD_WriteData(0x3A);
  LCD_WriteData(0x3A);      
  LCD_WriteCMD(0xB3); 
  LCD_WriteData(0x05);
  LCD_WriteData(0x3A);
  LCD_WriteData(0x3A);   
  LCD_WriteData(0x05);
  LCD_WriteData(0x3A);
  LCD_WriteData(0x3A);   
  LCD_WriteCMD(0xB4); 
  LCD_WriteData(0x03);

  LCD_WriteCMD(0xC0); 
  LCD_WriteData(0x62);
  LCD_WriteData(0x02);
  LCD_WriteData(0x04);
  LCD_WriteCMD(0xC1); 
  LCD_WriteData(0xC0);
  LCD_WriteCMD(0xC2);
  LCD_WriteData(0x0D);   
  LCD_WriteData(0x00);
  LCD_WriteCMD(0xC3);
  LCD_WriteData(0x8D);   
  LCD_WriteData(0x6A);           
  LCD_WriteCMD(0xC4);
  LCD_WriteData(0x8D);   
  LCD_WriteData(0xEE); 
  LCD_WriteCMD(0xC5);
  LCD_WriteData(0x12); 

//GAMMA
  LCD_WriteCMD(0xE0);
  LCD_WriteData(0x03); 
  LCD_WriteData(0x1B); 
  LCD_WriteData(0x12); 
  LCD_WriteData(0x11); 
  LCD_WriteData(0x3F); 
  LCD_WriteData(0x3A); 
  LCD_WriteData(0x32); 
  LCD_WriteData(0x34); 
  LCD_WriteData(0x2F); 
  LCD_WriteData(0x2B); 
  LCD_WriteData(0x30); 
  LCD_WriteData(0x3A); 
  LCD_WriteData(0x00); 
  LCD_WriteData(0x01); 
  LCD_WriteData(0x02); 
  LCD_WriteData(0x05); 
  LCD_WriteCMD(0xE1);
  LCD_WriteData(0x03); 
  LCD_WriteData(0x1B); 
  LCD_WriteData(0x12); 
  LCD_WriteData(0x11); 
  LCD_WriteData(0x32); 
  LCD_WriteData(0x2F); 
  LCD_WriteData(0x2A); 
  LCD_WriteData(0x2F); 
  LCD_WriteData(0x2E); 
  LCD_WriteData(0x2C); 
  LCD_WriteData(0x35); 
  LCD_WriteData(0x3F); 
  LCD_WriteData(0x00); 
  LCD_WriteData(0x00); 
  LCD_WriteData(0x01); 
  LCD_WriteData(0x05); 

  LCD_WriteCMD(0xFC);
  LCD_WriteData(0x8C); 
  LCD_WriteCMD(0x3A);
  LCD_WriteData(0x05); 
  LCD_WriteCMD(0x36);
  LCD_WriteData(0xC8);

  LCD_WriteCMD(0x29);

  nrf_gpio_pin_write(LCD_BL,1);
  LCD_Clear(BLUE);
  LCD_ShowString(0,60,"Channal A:",WHITE);
  LCD_ShowString(0,80,"Channal B:",WHITE);
  LCD_ShowString(0,100,"Disconnected!",WHITE);  
}

		   
	 
void LCD_ShowChar(uint16_t x,uint16_t y,uint8_t num,uint16_t color)
{
  uint8_t temp;
  uint8_t pos,t;
  uint16_t x0=x;           
  num=num-' ';
  LCD_Setwindow(x,x+8-1,y,y+16-1);     

  for(pos=0;pos<16;pos++)
   { 
    temp=asc2_1608[(uint16_t)num*16+pos];		 
    for(t=0;t<8;t++)
    {                 
      if(temp&0x01)LCD_Write_Color(color);
      else LCD_Write_Color(BLUE);
      temp>>=1; 
      x++;
    }
    x=x0;
    y++;
  }
}

void LCD_ShowString(uint16_t x,uint16_t y,const uint8_t *p,uint16_t color)
{   
    nrf_gpio_pin_write(LCD_BL,1);    
    while(*p!='\0')
    {       
        LCD_ShowChar(x,y,*p,color);
        x+=8;
        p++;
    }  
}


uint32_t mypow(uint8_t m,uint8_t n)
{
  uint32_t result=1;	 
  while(n--)result*=m;    
  return result;
}

void LCD_ShowNum(uint16_t x,uint16_t y,uint16_t num,uint8_t len,uint16_t color)
{         	
  uint8_t t,temp;
  uint8_t enshow=0;
  for(t=0;t<len;t++)
  {
    temp=(num/mypow(10,len-t-1))%10;
    if(enshow==0&&t<(len-1))
    {
      if(temp==0)
      {
        LCD_ShowChar(x+8*t,y,' ',color);
        continue;
      }else enshow=1;      
    }
    LCD_ShowChar(x+8*t,y,temp+48,color); 
  }
} 
