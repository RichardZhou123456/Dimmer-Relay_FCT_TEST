#ifndef _LDS_TIMER_H_
#define _LDS_TIMER_H_


void LdsTimer4Init(xt_u32 time_ms);

xt_u32 LdsTimer4CountMsGet(void);


#endif
