#ifndef _LDS_MAIN_H_
#define _LDS_MAIN_H_


void LdsRfTask(void);


#endif
