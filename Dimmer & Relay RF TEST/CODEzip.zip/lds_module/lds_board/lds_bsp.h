#ifndef _LDS_BSP_H_
#define _LDS_BSP_H_


void LdsBspEvenNumberPinLow(void);

void LdsBspEvenNumberPinHigh(void);

void LdsBspOddNumberPinLow(void);

void LdsBspOddNumberPinHigh(void);

void LdsBspGpioInit(void);

#endif
