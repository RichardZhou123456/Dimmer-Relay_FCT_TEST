extern void pwm_init(void);
extern void pwm_set_dutycycle(uint32_t value);